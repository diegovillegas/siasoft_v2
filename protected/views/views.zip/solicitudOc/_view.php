<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('SOLICITUD_OC')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->SOLICITUD_OC), array('view', 'id'=>$data->SOLICITUD_OC)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('DEPARTAMENTO')); ?>:</b>
	<?php echo CHtml::encode($data->DEPARTAMENTO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_SOLICITUD')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_SOLICITUD); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_REQUERIDA')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_REQUERIDA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('AUTORIZADA_POR')); ?>:</b>
	<?php echo CHtml::encode($data->AUTORIZADA_POR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_AUTORIZADA')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_AUTORIZADA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('PRIORIDAD')); ?>:</b>
	<?php echo CHtml::encode($data->PRIORIDAD); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('LINEAS_NO_ASIG')); ?>:</b>
	<?php echo CHtml::encode($data->LINEAS_NO_ASIG); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('COMENTARIO')); ?>:</b>
	<?php echo CHtml::encode($data->COMENTARIO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CANCELADA_POR')); ?>:</b>
	<?php echo CHtml::encode($data->CANCELADA_POR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_CANCELADA')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_CANCELADA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('RUBRO1')); ?>:</b>
	<?php echo CHtml::encode($data->RUBRO1); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('RUBRO2')); ?>:</b>
	<?php echo CHtml::encode($data->RUBRO2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('RUBRO3')); ?>:</b>
	<?php echo CHtml::encode($data->RUBRO3); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('RUBRO4')); ?>:</b>
	<?php echo CHtml::encode($data->RUBRO4); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('RUBRO5')); ?>:</b>
	<?php echo CHtml::encode($data->RUBRO5); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ESTADO')); ?>:</b>
	<?php echo CHtml::encode($data->ESTADO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CREADO_POR')); ?>:</b>
	<?php echo CHtml::encode($data->CREADO_POR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CREADO_EL')); ?>:</b>
	<?php echo CHtml::encode($data->CREADO_EL); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ACTUALIZADO_POR')); ?>:</b>
	<?php echo CHtml::encode($data->ACTUALIZADO_POR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ACTUALIZADO_EL')); ?>:</b>
	<?php echo CHtml::encode($data->ACTUALIZADO_EL); ?>
	<br />

	*/ ?>

</div>