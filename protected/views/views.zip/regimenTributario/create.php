<?php
/* @var $this RegimenTributarioController */
/* @var $model RegimenTributario */

$this->breadcrumbs=array(
	'Regimen Tributario'=>array('admin'),
	'Create',
);
?>

<h1>Create RegimenTributario</h1>

<?php echo $this->renderPartial('_form', array('model2'=>$model2)); ?>