<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('ORDEN_COMPRA_LINEA')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->ORDEN_COMPRA_LINEA), array('view', 'id'=>$data->ORDEN_COMPRA_LINEA)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ORDEN_COMPRA')); ?>:</b>
	<?php echo CHtml::encode($data->ORDEN_COMPRA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('LINEA_NUM')); ?>:</b>
	<?php echo CHtml::encode($data->LINEA_NUM); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ARTICULO')); ?>:</b>
	<?php echo CHtml::encode($data->ARTICULO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('DESCRIPCION')); ?>:</b>
	<?php echo CHtml::encode($data->DESCRIPCION); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('BODEGA')); ?>:</b>
	<?php echo CHtml::encode($data->BODEGA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_REQUERIDA')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_REQUERIDA); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('FACTURA')); ?>:</b>
	<?php echo CHtml::encode($data->FACTURA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CANTIDAD_ORDENADA')); ?>:</b>
	<?php echo CHtml::encode($data->CANTIDAD_ORDENADA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('UNIDAD_COMPRA')); ?>:</b>
	<?php echo CHtml::encode($data->UNIDAD_COMPRA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('PRECIO_UNITARIO')); ?>:</b>
	<?php echo CHtml::encode($data->PRECIO_UNITARIO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('PORC_DESCUENTO')); ?>:</b>
	<?php echo CHtml::encode($data->PORC_DESCUENTO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('MONTO_DESCUENTO')); ?>:</b>
	<?php echo CHtml::encode($data->MONTO_DESCUENTO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('VALOR_IMPUESTO')); ?>:</b>
	<?php echo CHtml::encode($data->VALOR_IMPUESTO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CANTIDAD_RECIBIDA')); ?>:</b>
	<?php echo CHtml::encode($data->CANTIDAD_RECIBIDA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CANTIDAD_RECHAZADA')); ?>:</b>
	<?php echo CHtml::encode($data->CANTIDAD_RECHAZADA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('OBSERVACION')); ?>:</b>
	<?php echo CHtml::encode($data->OBSERVACION); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ESTADO')); ?>:</b>
	<?php echo CHtml::encode($data->ESTADO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CREADO_POR')); ?>:</b>
	<?php echo CHtml::encode($data->CREADO_POR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CREADO_EL')); ?>:</b>
	<?php echo CHtml::encode($data->CREADO_EL); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ACTUALIZADO_POR')); ?>:</b>
	<?php echo CHtml::encode($data->ACTUALIZADO_POR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ACTUALIZADO_EL')); ?>:</b>
	<?php echo CHtml::encode($data->ACTUALIZADO_EL); ?>
	<br />

	*/ ?>

</div>