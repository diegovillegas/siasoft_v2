<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('SOLICITUD_OC_LINEA')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->SOLICITUD_OC_LINEA), array('view', 'id'=>$data->SOLICITUD_OC_LINEA)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('SOLICITUD_OC')); ?>:</b>
	<?php echo CHtml::encode($data->SOLICITUD_OC); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('LINEA_NUM')); ?>:</b>
	<?php echo CHtml::encode($data->LINEA_NUM); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ARTICULO')); ?>:</b>
	<?php echo CHtml::encode($data->ARTICULO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('DESCRIPCION')); ?>:</b>
	<?php echo CHtml::encode($data->DESCRIPCION); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CANTIDAD')); ?>:</b>
	<?php echo CHtml::encode($data->CANTIDAD); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('SALDO')); ?>:</b>
	<?php echo CHtml::encode($data->SALDO); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('COMENTARIO')); ?>:</b>
	<?php echo CHtml::encode($data->COMENTARIO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_REQUERIDA')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_REQUERIDA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ESTADO')); ?>:</b>
	<?php echo CHtml::encode($data->ESTADO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CREADO_POR')); ?>:</b>
	<?php echo CHtml::encode($data->CREADO_POR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CREADO_EL')); ?>:</b>
	<?php echo CHtml::encode($data->CREADO_EL); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ACTUALIZADO_POR')); ?>:</b>
	<?php echo CHtml::encode($data->ACTUALIZADO_POR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ACTUALIZADO_EL')); ?>:</b>
	<?php echo CHtml::encode($data->ACTUALIZADO_EL); ?>
	<br />

	*/ ?>

</div>