<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('ORDEN_COMPRA')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->ORDEN_COMPRA), array('view', 'id'=>$data->ORDEN_COMPRA)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('PROVEEDOR')); ?>:</b>
	<?php echo CHtml::encode($data->PROVEEDOR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('BODEGA')); ?>:</b>
	<?php echo CHtml::encode($data->BODEGA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('DEPARTAMENTO')); ?>:</b>
	<?php echo CHtml::encode($data->DEPARTAMENTO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_COTIZACION')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_COTIZACION); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_OFRECIDA')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_OFRECIDA); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_REQUERIDA')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_REQUERIDA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_REQ_EMBARQUE')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_REQ_EMBARQUE); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('PRIORIDAD')); ?>:</b>
	<?php echo CHtml::encode($data->PRIORIDAD); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CONDICION_PAGO')); ?>:</b>
	<?php echo CHtml::encode($data->CONDICION_PAGO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('DIRECCION_EMBARQUE')); ?>:</b>
	<?php echo CHtml::encode($data->DIRECCION_EMBARQUE); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('DIRECCION_COBRO')); ?>:</b>
	<?php echo CHtml::encode($data->DIRECCION_COBRO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('RUBRO1')); ?>:</b>
	<?php echo CHtml::encode($data->RUBRO1); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('RUBRO2')); ?>:</b>
	<?php echo CHtml::encode($data->RUBRO2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('RUBRO3')); ?>:</b>
	<?php echo CHtml::encode($data->RUBRO3); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('RUBRO4')); ?>:</b>
	<?php echo CHtml::encode($data->RUBRO4); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('RUBRO5')); ?>:</b>
	<?php echo CHtml::encode($data->RUBRO5); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('COMENTARIO_CXP')); ?>:</b>
	<?php echo CHtml::encode($data->COMENTARIO_CXP); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('INSTRUCCIONES')); ?>:</b>
	<?php echo CHtml::encode($data->INSTRUCCIONES); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('OBSERVACIONES')); ?>:</b>
	<?php echo CHtml::encode($data->OBSERVACIONES); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('PORC_DESCUENTO')); ?>:</b>
	<?php echo CHtml::encode($data->PORC_DESCUENTO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('MONTO_FLETE')); ?>:</b>
	<?php echo CHtml::encode($data->MONTO_FLETE); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('MONTO_SEGURO')); ?>:</b>
	<?php echo CHtml::encode($data->MONTO_SEGURO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('MONTO_ANTICIPO')); ?>:</b>
	<?php echo CHtml::encode($data->MONTO_ANTICIPO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('TIPO_PRORRATEO_OC')); ?>:</b>
	<?php echo CHtml::encode($data->TIPO_PRORRATEO_OC); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('TOTAL_A_COMPRAR')); ?>:</b>
	<?php echo CHtml::encode($data->TOTAL_A_COMPRAR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('USUARIO_CANCELA')); ?>:</b>
	<?php echo CHtml::encode($data->USUARIO_CANCELA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('FECHA_CANCELA')); ?>:</b>
	<?php echo CHtml::encode($data->FECHA_CANCELA); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ESTADO')); ?>:</b>
	<?php echo CHtml::encode($data->ESTADO); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CREADO_POR')); ?>:</b>
	<?php echo CHtml::encode($data->CREADO_POR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('CREADO_EL')); ?>:</b>
	<?php echo CHtml::encode($data->CREADO_EL); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ACTUALIZADO_POR')); ?>:</b>
	<?php echo CHtml::encode($data->ACTUALIZADO_POR); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ACTUALIZADO_EL')); ?>:</b>
	<?php echo CHtml::encode($data->ACTUALIZADO_EL); ?>
	<br />

	*/ ?>

</div>