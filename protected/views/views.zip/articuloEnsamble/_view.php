<div class="modal-body">     
    <div id="ver-detalle"></div>
</div>
<div class="modal-footer">
    <?php $this->widget('bootstrap.widgets.BootButton', array(
                    'label'=>'Aceptar',
                    'url'=>'#',
                    'htmlOptions'=>array('data-dismiss'=>'modal'),
                )); 
               
            ?>
</div>